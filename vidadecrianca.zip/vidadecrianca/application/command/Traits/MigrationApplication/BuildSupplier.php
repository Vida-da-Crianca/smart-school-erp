<?php

namespace Application\Command\Traits\MigrationApplication;


trait BuildSupplier
{

}