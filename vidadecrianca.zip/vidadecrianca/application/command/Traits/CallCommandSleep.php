<?php

namespace Application\Command\Traits;

// use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Collection as SupportCollection;

trait CallCommandSleep
{


    
    public function callCommands($command, $secounds = 30){
         
    }
}
